#!/bin/bash
echo "hello manhattan"
