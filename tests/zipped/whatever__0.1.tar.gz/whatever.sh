#!/bin/bash
echo "was $1"
exit $1
