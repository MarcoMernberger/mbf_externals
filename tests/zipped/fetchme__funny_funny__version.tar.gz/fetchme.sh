#!/bin/bash
echo "fetched"